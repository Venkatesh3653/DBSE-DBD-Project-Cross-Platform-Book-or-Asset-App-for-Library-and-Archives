const express = require("express");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, "data.json");

app.use(express.json());
app.use(express.static(__dirname, { index: false }));

const sessions = new Map();
const SESSION_COOKIE = "libraryhub_session";
const SESSION_MAX_AGE = 24 * 60 * 60 * 1000;

function getSessionToken(req) {
  const cookies = String(req.headers.cookie || "").split(";").map(x => x.trim());
  const item = cookies.find(x => x.startsWith(SESSION_COOKIE + "="));
  return item ? decodeURIComponent(item.slice((SESSION_COOKIE + "=").length)) : null;
}

function getCurrentUser(req) {
  const token = getSessionToken(req);
  if (!token) return null;

  const session = sessions.get(token);
  if (!session || session.expiresAt < Date.now()) {
    if (session) sessions.delete(token);
    return null;
  }

  session.expiresAt = Date.now() + SESSION_MAX_AGE;
  const db = readData();
  return db.users.find(u => u.id === session.userId) || null;
}

function createSession(res, userId) {
  const token = crypto.randomBytes(32).toString("hex");
  sessions.set(token, {
    userId,
    expiresAt: Date.now() + SESSION_MAX_AGE
  });

  res.setHeader(
    "Set-Cookie",
    `${SESSION_COOKIE}=${encodeURIComponent(token)}; HttpOnly; Path=/; SameSite=Lax; Max-Age=${SESSION_MAX_AGE / 1000}`
  );
}

function clearSession(req, res) {
  const token = getSessionToken(req);
  if (token) sessions.delete(token);
  res.setHeader(
    "Set-Cookie",
    `${SESSION_COOKIE}=; HttpOnly; Path=/; SameSite=Lax; Max-Age=0`
  );
}

function requireAuth(req, res, next) {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: "Authentication required" });
  req.user = user;
  next();
}

function readData() {
  return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
}

function writeData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

function nextId(items) {
  return items.length ? Math.max(...items.map(x => x.id)) + 1 : 1;
}


function hashPassword(password, salt = crypto.randomBytes(16).toString("hex")) {
  const hash = crypto.scryptSync(password, salt, 64).toString("hex");
  return { salt, hash };
}

function verifyPassword(password, salt, storedHash) {
  const hash = crypto.scryptSync(password, salt, 64).toString("hex");
  return crypto.timingSafeEqual(
    Buffer.from(hash, "hex"),
    Buffer.from(storedHash, "hex")
  );
}

app.post("/api/auth/signup", (req, res) => {
  const { name, email, password } = req.body;

  if (!name || !email || !password) {
    return res.status(400).json({ error: "All fields are required" });
  }

  if (password.length < 6) {
    return res.status(400).json({ error: "Password must be at least 6 characters" });
  }

  const db = readData();
  const normalizedEmail = email.trim().toLowerCase();

  if (db.users.some(u => u.email.toLowerCase() === normalizedEmail)) {
    return res.status(409).json({ error: "An account with this email already exists" });
  }

  const passwordData = hashPassword(password);

  const user = {
    id: nextId(db.users),
    name: name.trim(),
    email: normalizedEmail,
    passwordHash: passwordData.hash,
    passwordSalt: passwordData.salt
  };

  db.users.push(user);
  writeData(db);
  createSession(res, user.id);

  res.status(201).json({
    message: "Account created",
    user: { id: user.id, name: user.name, email: user.email }
  });
});

app.post("/api/auth/signin", (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: "Email and password are required" });
  }

  const db = readData();
  const user = db.users.find(
    u => u.email.toLowerCase() === email.trim().toLowerCase()
  );

  if (!user || !user.passwordHash || !user.passwordSalt) {
    return res.status(401).json({ error: "Invalid email or password" });
  }

  if (!verifyPassword(password, user.passwordSalt, user.passwordHash)) {
    return res.status(401).json({ error: "Invalid email or password" });
  }

  createSession(res, user.id);

  res.json({
    message: "Signed in successfully",
    user: { id: user.id, name: user.name, email: user.email }
  });
});

app.post("/api/auth/logout", (req, res) => {
  clearSession(req, res);
  res.json({ message: "Signed out" });
});

app.get("/api/auth/me", (req, res) => {
  const user = getCurrentUser(req);
  if (!user) return res.status(401).json({ error: "Authentication required" });

  res.json({
    user: { id: user.id, name: user.name, email: user.email }
  });
});

app.use("/api", requireAuth);

app.get("/api/stats", (req, res) => {
  const db = readData();

  res.json({
    totalBooks: db.books.length,
    borrowedBooks: db.loans.length,
    reservedBooks: db.reservations.length,
    archives: db.assets.filter(a => a.type === "Archive").length
  });
});

app.get("/api/books", (req, res) => {
  const db = readData();
  const search = String(req.query.search || "").toLowerCase();
  const category = String(req.query.category || "").toLowerCase();

  const books = db.books.filter(book => {
    const matchesSearch =
      !search ||
      book.title.toLowerCase().includes(search) ||
      book.author.toLowerCase().includes(search);

    const matchesCategory =
      !category || book.category.toLowerCase() === category;

    return matchesSearch && matchesCategory;
  });

  res.json(books);
});

app.post("/api/loans", (req, res) => {
  const { userId, bookId } = req.body;
  const db = readData();
  const book = db.books.find(b => b.id === Number(bookId));

  if (!book) return res.status(404).json({ error: "Book not found" });
  if (book.status !== "Available") {
    return res.status(400).json({ error: "Book is not available" });
  }

  const existing = db.loans.find(
    l => l.userId === Number(userId) && l.bookId === Number(bookId)
  );

  if (existing) return res.status(400).json({ error: "You already borrowed this book" });

  const due = new Date();
  due.setDate(due.getDate() + 14);

  db.loans.push({
    id: nextId(db.loans),
    userId: Number(userId),
    bookId: Number(bookId),
    date: new Date().toISOString().slice(0, 10),
    dueDate: due.toISOString().slice(0, 10)
  });

  book.status = "Borrowed";
  writeData(db);
  res.json({ message: "Book borrowed", book });
});

app.post("/api/reservations", (req, res) => {
  const { userId, bookId } = req.body;
  const db = readData();
  const book = db.books.find(b => b.id === Number(bookId));

  if (!book) return res.status(404).json({ error: "Book not found" });

  const existing = db.reservations.find(
    r => r.userId === Number(userId) && r.bookId === Number(bookId)
  );

  if (existing) return res.status(400).json({ error: "Already reserved" });

  db.reservations.push({
    id: nextId(db.reservations),
    userId: Number(userId),
    bookId: Number(bookId),
    date: new Date().toISOString().slice(0, 10)
  });

  book.status = "Reserved";
  writeData(db);
  res.json({ message: "Book reserved" });
});

app.get("/api/users/:id/loans", (req, res) => {
  const db = readData();
  const userId = Number(req.params.id);

  const loans = db.loans
    .filter(l => l.userId === userId)
    .map(l => {
      const book = db.books.find(b => b.id === l.bookId);
      return {
        title: book ? book.title : "Unknown book",
        type: "Borrowed",
        date: l.date,
        dueDate: l.dueDate
      };
    });

  const reservations = db.reservations
    .filter(r => r.userId === userId)
    .map(r => {
      const book = db.books.find(b => b.id === r.bookId);
      return {
        title: book ? book.title : "Unknown book",
        type: "Reserved",
        date: r.date,
        dueDate: null
      };
    });

  res.json([...loans, ...reservations]);
});

app.post("/api/favorites", (req, res) => {
  const { userId, bookId } = req.body;
  const db = readData();

  const index = db.favorites.findIndex(
    f => f.userId === Number(userId) && f.bookId === Number(bookId)
  );

  if (index >= 0) {
    db.favorites.splice(index, 1);
  } else {
    db.favorites.push({
      id: nextId(db.favorites),
      userId: Number(userId),
      bookId: Number(bookId)
    });
  }

  writeData(db);
  res.json({ message: "Favorites updated" });
});

app.get("/api/users/:id/favorites", (req, res) => {
  const db = readData();
  const userId = Number(req.params.id);

  const books = db.favorites
    .filter(f => f.userId === userId)
    .map(f => db.books.find(b => b.id === f.bookId))
    .filter(Boolean);

  res.json(books);
});

app.get("/api/assets", (req, res) => {
  const db = readData();
  res.json(db.assets);
});

app.post("/api/asset-reservations", (req, res) => {
  const { userId, assetId } = req.body;
  const db = readData();
  const asset = db.assets.find(a => a.id === Number(assetId));

  if (!asset) return res.status(404).json({ error: "Asset not found" });

  db.assetReservations.push({
    id: nextId(db.assetReservations),
    userId: Number(userId),
    assetId: Number(assetId),
    date: new Date().toISOString().slice(0, 10)
  });

  if (asset.status === "Available") asset.status = "Reserved";

  writeData(db);
  res.json({ message: "Asset request submitted" });
});

app.get("/", (req, res) => {
  if (!getCurrentUser(req)) {
    return res.redirect("/auth.html");
  }
  res.sendFile(path.join(__dirname, "index.html"));
});

app.use((req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

app.listen(PORT, () => {
  console.log(`LibraryHub running at http://localhost:${PORT}`);
});
