# LibraryHub Full-Stack Version

## Features added
- User login with persistent local user record
- Live dashboard statistics
- Search by title/author
- Category filtering
- Borrow books with 14-day due dates
- Reserve books
- My Books section
- Favorites
- Library asset booking
- REST API backend
- JSON data persistence

## Requirements
- Node.js 18+ recommended
- npm

## Run
Open a terminal in this folder:

```bash
npm install
npm start
```

Then open:

http://localhost:3000

## Important
The current backend uses `data.json` as a simple database so the project is easy to run for a college demonstration.
For a production version, replace this storage layer with MongoDB/MySQL/PostgreSQL.

## Main API endpoints
GET  /api/stats
GET  /api/books
POST /api/users/login
POST /api/loans
POST /api/reservations
GET  /api/users/:id/loans
POST /api/favorites
GET  /api/users/:id/favorites
GET  /api/assets
POST /api/asset-reservations

## Authentication
- `/auth.html` contains separate Sign In and Sign Up forms.
- Sign Up creates an account.
- Passwords are hashed with Node.js `crypto.scryptSync` before being stored.
- Sign In verifies the password against the stored hash.
- Successful authentication returns the user to the LibraryHub home page.

For a production deployment, add server-side sessions/JWT, HTTPS, rate limiting, email verification, password reset, and a real database.
