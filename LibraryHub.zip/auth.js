function showForm(type) {
  const signin = document.getElementById("signinForm");
  const signup = document.getElementById("signupForm");
  const signinTab = document.getElementById("signinTab");
  const signupTab = document.getElementById("signupTab");

  clearMessage();

  if (type === "signin") {
    signin.classList.remove("hidden");
    signup.classList.add("hidden");
    signinTab.classList.add("active");
    signupTab.classList.remove("active");
  } else {
    signup.classList.remove("hidden");
    signin.classList.add("hidden");
    signupTab.classList.add("active");
    signinTab.classList.remove("active");
  }
}

function togglePassword(id, button) {
  const input = document.getElementById(id);
  input.type = input.type === "password" ? "text" : "password";
  button.textContent = input.type === "password" ? "Show" : "Hide";
}

function showMessage(text, type) {
  const message = document.getElementById("message");
  message.textContent = text;
  message.className = "message show " + type;
}

function clearMessage() {
  const message = document.getElementById("message");
  message.textContent = "";
  message.className = "message";
}

async function signUp(event) {
  event.preventDefault();

  const name = document.getElementById("signupName").value.trim();
  const email = document.getElementById("signupEmail").value.trim();
  const password = document.getElementById("signupPassword").value;
  const confirm = document.getElementById("signupConfirm").value;

  if (password !== confirm) {
    showMessage("Passwords do not match.", "error");
    return;
  }

  try {
    const response = await fetch("/api/auth/signup", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({name, email, password})
    });

    const data = await response.json();

    if (!response.ok) {
      showMessage(data.error || "Sign up failed.", "error");
      return;
    }

    localStorage.setItem("libraryUser", JSON.stringify(data.user));
    showMessage("Account created successfully. Redirecting...", "success");

    setTimeout(() => {
      window.location.href = "/";
    }, 700);
  } catch (error) {
    showMessage("Cannot connect to the server.", "error");
  }
}

async function signIn(event) {
  event.preventDefault();

  const email = document.getElementById("signinEmail").value.trim();
  const password = document.getElementById("signinPassword").value;

  try {
    const response = await fetch("/api/auth/signin", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({email, password})
    });

    const data = await response.json();

    if (!response.ok) {
      showMessage(data.error || "Sign in failed.", "error");
      return;
    }

    localStorage.setItem("libraryUser", JSON.stringify(data.user));
    showMessage("Login successful. Redirecting...", "success");

    setTimeout(() => {
      window.location.href = "/";
    }, 500);
  } catch (error) {
    showMessage("Cannot connect to the server.", "error");
  }
}
