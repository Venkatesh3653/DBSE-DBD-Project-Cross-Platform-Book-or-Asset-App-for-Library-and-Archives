const API = "/api";
let currentUser = JSON.parse(localStorage.getItem("libraryUser") || "null");

document.addEventListener("DOMContentLoaded", async () => {
  try {
    const response = await fetch("/api/auth/me");
    if (!response.ok) {
      localStorage.removeItem("libraryUser");
      window.location.replace("/auth.html");
      return;
    }

    const data = await response.json();
    currentUser = data.user;
    localStorage.setItem("libraryUser", JSON.stringify(currentUser));

    updateUserUI();
    loadBooks();
    loadAssets();
    loadStats();
    loadMyBooks();
    loadFavorites();
  } catch (error) {
    localStorage.removeItem("libraryUser");
    window.location.replace("/auth.html");
  }
});

function showToast(message) {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 2500);
}

async function api(url, options = {}) {
  const response = await fetch(API + url, {
    headers: { "Content-Type": "application/json" },
    ...options
  });

  if (response.status === 401) {
    localStorage.removeItem("libraryUser");
    window.location.replace("/auth.html");
    throw new Error("Authentication required");
  }

  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Something went wrong");
  return data;
}

function login() {
  window.location.href = "/auth.html";
}

function closeLogin() {
  window.location.href = "/auth.html";
}

async function submitLogin() {
  window.location.href = "/auth.html";
}

async function logout() {
  try {
    await fetch("/api/auth/logout", { method: "POST" });
  } finally {
    currentUser = null;
    localStorage.removeItem("libraryUser");
    window.location.replace("/auth.html");
  }
}

function updateUserUI() {
  document.getElementById("userName").textContent =
    currentUser ? "Hi, " + currentUser.name : "";

  document.getElementById("loginBtn").classList.toggle("hidden", !!currentUser);
  document.getElementById("logoutBtn").classList.toggle("hidden", !currentUser);
}

async function loadStats() {
  try {
    const stats = await api("/stats");
    document.getElementById("totalBooks").textContent = stats.totalBooks;
    document.getElementById("borrowedBooks").textContent = stats.borrowedBooks;
    document.getElementById("reservedBooks").textContent = stats.reservedBooks;
    document.getElementById("archiveCount").textContent = stats.archives;
  } catch (error) {
    console.error(error);
  }
}

async function loadBooks() {
  const query = document.getElementById("search").value.trim();
  const category = document.getElementById("categoryFilter").value;

  try {
    const books = await api(
      "/books?search=" + encodeURIComponent(query) +
      "&category=" + encodeURIComponent(category)
    );

    const list = document.getElementById("bookList");

    if (!books.length) {
      list.innerHTML = '<p class="empty">No books found.</p>';
      return;
    }

    list.innerHTML = books.map(book => `
      <div class="book">
        <div class="cover">${book.icon}</div>
        <h3>${escapeHtml(book.title)}</h3>
        <p>${escapeHtml(book.author)}</p>
        <small class="muted">${escapeHtml(book.category)}</small><br>
        <span class="status ${book.status.toLowerCase()}">${book.status}</span>
        <div class="book-actions">
          ${
            book.status === "Available"
            ? `<button onclick="borrow(${book.id})">Borrow</button>`
            : `<button onclick="reserve(${book.id})">Reserve</button>`
          }
          <button class="favorite" onclick="toggleFavorite(${book.id})">⭐</button>
        </div>
      </div>
    `).join("");
  } catch (error) {
    showToast(error.message);
  }
}

async function borrow(bookId) {
  if (!requireLogin()) return;

  try {
    await api("/loans", {
      method: "POST",
      body: JSON.stringify({ userId: currentUser.id, bookId })
    });

    showToast("Book borrowed successfully");
    refreshAll();
  } catch (error) {
    showToast(error.message);
  }
}

async function reserve(bookId) {
  if (!requireLogin()) return;

  try {
    await api("/reservations", {
      method: "POST",
      body: JSON.stringify({ userId: currentUser.id, bookId })
    });

    showToast("Book reserved successfully");
    refreshAll();
  } catch (error) {
    showToast(error.message);
  }
}

async function toggleFavorite(bookId) {
  if (!requireLogin()) return;

  try {
    await api("/favorites", {
      method: "POST",
      body: JSON.stringify({ userId: currentUser.id, bookId })
    });

    loadFavorites();
    showToast("Favorites updated");
  } catch (error) {
    showToast(error.message);
  }
}

async function loadMyBooks() {
  const list = document.getElementById("myBooksList");

  if (!currentUser) {
    list.innerHTML = '<p class="empty">Login to view your books.</p>';
    return;
  }

  try {
    const items = await api("/users/" + currentUser.id + "/loans");

    if (!items.length) {
      list.innerHTML = '<p class="empty">You have no borrowed or reserved books.</p>';
      return;
    }

    list.innerHTML = items.map(item => `
      <div class="history-item">
        <div>
          <strong>${escapeHtml(item.title)}</strong>
          <p class="muted">${item.type} • ${item.date}</p>
        </div>
        <b>${item.dueDate ? "Due: " + item.dueDate : "Reserved"}</b>
      </div>
    `).join("");
  } catch (error) {
    showToast(error.message);
  }
}

async function loadFavorites() {
  const list = document.getElementById("favoritesList");

  if (!currentUser) {
    list.innerHTML = '<p class="empty">Login to save favorites.</p>';
    return;
  }

  try {
    const books = await api("/users/" + currentUser.id + "/favorites");

    if (!books.length) {
      list.innerHTML = '<p class="empty">No favorites yet.</p>';
      return;
    }

    list.innerHTML = books.map(book =>
      `<span class="favorite-tag">${book.icon} ${escapeHtml(book.title)}</span>`
    ).join("");
  } catch (error) {
    showToast(error.message);
  }
}

async function loadAssets() {
  try {
    const assets = await api("/assets");
    document.getElementById("assetList").innerHTML = assets.map(asset => `
      <div class="asset">
        <h3>${asset.icon} ${escapeHtml(asset.name)}</h3>
        <p>${escapeHtml(asset.description)}</p>
        <b>${asset.status}</b>
        <button onclick="reserveAsset(${asset.id})">
          ${asset.status === "Available" ? "Book Asset" : "Request Asset"}
        </button>
      </div>
    `).join("");
  } catch (error) {
    showToast(error.message);
  }
}

async function reserveAsset(assetId) {
  if (!requireLogin()) return;

  try {
    await api("/asset-reservations", {
      method: "POST",
      body: JSON.stringify({ userId: currentUser.id, assetId })
    });

    showToast("Asset request submitted");
    loadAssets();
  } catch (error) {
    showToast(error.message);
  }
}

function requireLogin() {
  if (!currentUser) {
    showToast("Please login first");
    login();
    return false;
  }
  return true;
}

function refreshAll() {
  loadBooks();
  loadAssets();
  loadStats();
  loadMyBooks();
  loadFavorites();
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
